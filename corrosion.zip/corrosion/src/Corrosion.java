import java.util.Scanner;

public class Corrosion {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] nombresMetales = {
                "Oro (Au)",
                "Agua (H2O / O2)",
                "Platino (Pt)",
                "Plata (Ag)",
                "Mercurio (Hg)",
                "Hierro (Fe2+ / Fe3+)",
                "Hidróxido (OH- / O2)",
                "Cobre (Cu)",
                "Estaño (Sn2+ / Sn4+)",
                "Hidrógeno (H2)",
                "Plomo (Pb)",
                "Estaño (Sn)",
                "Níquel (Ni)",
                "Cobalto (Co)",
                "Cadmio (Cd)",
                "Hierro (Fe)",
                "Cromo (Cr)",
                "Zinc (Zn)",
                "Aluminio (Al)",
                "Magnesio (Mg)",
                "Sodio (Na)"
        };

        String[] especiesReducidas = {
                "Au",
                "H2O",
                "Pt",
                "Ag",
                "Hg",
                "Fe2+",
                "(OH)-",
                "Cu",
                "Sn2+",
                "H2",
                "Pb",
                "Sn",
                "Ni",
                "Co",
                "Cd",
                "Fe",
                "Cr",
                "Zn",
                "Al",
                "Mg",
                "Na"
        };

        int[] coeficientesReducidos = {
                1, 2, 1, 1, 2, 1, 4, 1, 1, 1,
                1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
        };

        String[] especiesOxidadas = {
                "Au3+",
                "O2 + 4H+",
                "Pt2+",
                "Ag+",
                "Hg2(2+)",
                "Fe3+",
                "O2 + 2H2O",
                "Cu2+",
                "Sn4+",
                "H+",
                "Pb2+",
                "Sn2+",
                "Ni2+",
                "Co2+",
                "Cd2+",
                "Fe2+",
                "Cr3+",
                "Zn2+",
                "Al3+",
                "Mg2+",
                "Na+"
        };

        int[] coeficientesOxidados = {
                1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
                1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
        };

        int[] electronesTabla = {
                3, 4, 2, 1, 2, 1, 4, 2, 2, 2,
                2, 2, 2, 2, 2, 2, 3, 2, 3, 2, 1
        };

        double[] potencialesEstandar = {
                1.498, 1.229, 1.200, 0.799, 0.788, 0.771, 0.401, 0.337, 0.150, 0.000,
                -0.126, -0.136, -0.250, -0.277, -0.403, -0.440, -0.744, -0.763, -1.662, -2.363, -2.714
        };

        boolean continuar = true;

        do {
            System.out.println();
            System.out.println("Calculadora de corrosión galvánica");
            System.out.println("1. Calcular par galvánico y balancear ecuación");
            System.out.println("2. Ver tabla de potenciales estándar (E°)");
            System.out.println("3. Salir");

            int opcionMenu;
            while (true) {
                try {
                    System.out.println("Elige una opción (1-3): ");
                    opcionMenu = scanner.nextInt();
                    if (opcionMenu >= 1 && opcionMenu <= 3) {
                        break;
                    } else {
                        System.out.println("ERROR: INGRESE UNA OPCIÓN VÁLIDA ENTRE 1 Y 3");
                    }
                } catch (Exception e) {
                    System.out.println("ERROR: INGRESE VALORES NUMÉRICOS ENTEROS");
                    scanner.nextLine();
                }
            }

            switch (opcionMenu) {
                case 1:
                    System.out.println();
                    System.out.println("Lista de metales y electrodos disponibles:");
                    for (int i = 0; i < nombresMetales.length; i++) {
                        System.out.printf("%d. %s | E° = %+.3f V | n = %de-%n",
                                (i + 1), nombresMetales[i], potencialesEstandar[i], electronesTabla[i]);
                    }

                    int indiceMetal1;
                    while (true) {
                        try {
                            System.out.println("Elige el primer electrodo (1-" + nombresMetales.length + "): ");
                            int seleccion1 = scanner.nextInt();
                            if (seleccion1 >= 1 && seleccion1 <= nombresMetales.length) {
                                indiceMetal1 = seleccion1 - 1;
                                break;
                            } else {
                                System.out.println("ERROR: ELIGE UN NÚMERO ENTRE 1 Y " + nombresMetales.length);
                            }
                        } catch (Exception e) {
                            System.out.println("ERROR: INGRESE VALORES NUMÉRICOS ENTEROS");
                            scanner.nextLine();
                        }
                    }

                    int indiceMetal2;
                    while (true) {
                        try {
                            System.out.println("Elige el segundo electrodo (1-" + nombresMetales.length + "): ");
                            int seleccion2 = scanner.nextInt();
                            if (seleccion2 < 1 || seleccion2 > nombresMetales.length) {
                                System.out.println("ERROR: ELIGE UN NÚMERO ENTRE 1 Y " + nombresMetales.length);
                            } else if ((seleccion2 - 1) == indiceMetal1) {
                                System.out.println("ERROR: NO PUEDES ELEGIR EL MISMO ELECTRODO DOS VECES");
                            } else {
                                indiceMetal2 = seleccion2 - 1;
                                break;
                            }
                        } catch (Exception e) {
                            System.out.println("ERROR: INGRESE VALORES NUMÉRICOS ENTEROS");
                            scanner.nextLine();
                        }
                    }

                    System.out.println();
                    System.out.println("Condiciones de concentración:");
                    System.out.println("1. Condiciones estándar (1 M para ambos)");
                    System.out.println("2. Condiciones no estándar (ingresar concentraciones)");

                    int tipoCondicion;
                    while (true) {
                        try {
                            System.out.println("Elige el tipo de condición (1-2): ");
                            tipoCondicion = scanner.nextInt();
                            if (tipoCondicion == 1 || tipoCondicion == 2) {
                                break;
                            } else {
                                System.out.println("ERROR: ELIGE 1 O 2");
                            }
                        } catch (Exception e) {
                            System.out.println("ERROR: INGRESE VALORES NUMÉRICOS ENTEROS");
                            scanner.nextLine();
                        }
                    }

                    double concentracion1 = 1.0;
                    double concentracion2 = 1.0;

                    if (tipoCondicion == 2) {
                        while (true) {
                            try {
                                System.out.println("Ingresa la concentración molar (M) para " + nombresMetales[indiceMetal1] + " (mayor a 0): ");
                                concentracion1 = scanner.nextDouble();
                                if (concentracion1 > 0) {
                                    break;
                                } else {
                                    System.out.println("ERROR: LA CONCENTRACIÓN DEBE SER MAYOR QUE 0");
                                }
                            } catch (Exception e) {
                                System.out.println("ERROR: INGRESE UN VALOR NUMÉRICO VÁLIDO");
                                scanner.nextLine();
                            }
                        }

                        while (true) {
                            try {
                                System.out.println("Ingresa la concentración molar (M) para " + nombresMetales[indiceMetal2] + " (mayor a 0): ");
                                concentracion2 = scanner.nextDouble();
                                if (concentracion2 > 0) {
                                    break;
                                } else {
                                    System.out.println("ERROR: LA CONCENTRACIÓN DEBE SER MAYOR QUE 0");
                                }
                            } catch (Exception e) {
                                System.out.println("ERROR: INGRESE UN VALOR NUMÉRICO VÁLIDO");
                                scanner.nextLine();
                            }
                        }
                    }


                    double potencialEstandarAnodo = -potencialesEstandar[indiceMetal1];
                    double potencialEstandarCatodo = potencialesEstandar[indiceMetal2];

                    double potencialRealAnodo = potencialEstandarAnodo + (0.0592 / electronesTabla[indiceMetal1]) * Math.log10(concentracion1);
                    double potencialRealCatodo = potencialEstandarCatodo + (0.0592 / electronesTabla[indiceMetal2]) * Math.log10(concentracion2);

                    double potencialReal1Redondeado = Math.round(potencialRealAnodo * 1000.0) / 1000.0;
                    double potencialReal2Redondeado = Math.round(potencialRealCatodo * 1000.0) / 1000.0;

                    double femEstandarConSigno = potencialEstandarAnodo + potencialEstandarCatodo;
                    double femEstandarRedondeada = Math.round(femEstandarConSigno * 1000.0) / 1000.0;

                    double femRealConSigno = potencialRealAnodo + potencialRealCatodo;
                    double femRealRedondeada = Math.round(femRealConSigno * 1000.0) / 1000.0;

                    System.out.println();
                    System.out.println("Resultados del par galvánico:");
                    System.out.printf("%s -> E° = %+.3f V | C = %.4f M | E = %+.4f V%n",
                            nombresMetales[indiceMetal1], potencialEstandarAnodo, concentracion1, potencialReal1Redondeado);
                    System.out.printf("%s -> E° = %+.3f V | C = %.4f M | E = %+.4f V%n",
                            nombresMetales[indiceMetal2], potencialEstandarCatodo, concentracion2, potencialReal2Redondeado);

                    if (potencialReal1Redondeado == potencialReal2Redondeado) {
                        System.out.println();
                        System.out.println("Estado: Equilibrio electroquímico (E celda = 0.0000 V)");
                        System.out.println("Ambos electrodos tienen el mismo potencial bajo estas condiciones; no ocurre corrosión galvánica neta.");
                        System.out.printf("Potencial estándar de celda (E° celda): %+.4f V%n", femEstandarRedondeada);
                    } else {
                        int indiceAnodo;
                        int indiceCatodo;

                        if (potencialEstandarAnodo < potencialEstandarCatodo) {
                            indiceAnodo = indiceMetal1;
                            indiceCatodo = indiceMetal2;
                        } else {
                            indiceAnodo = indiceMetal2;
                            indiceCatodo = indiceMetal1;
                        }

                        int electronesAnodo = electronesTabla[indiceAnodo];
                        int electronesCatodo = electronesTabla[indiceCatodo];

                        int mayor = Math.max(electronesAnodo, electronesCatodo);
                        int electronesTotales = mayor;
                        while (electronesTotales % electronesAnodo != 0 || electronesTotales % electronesCatodo != 0) {
                            electronesTotales += mayor;
                        }

                        int factorAnodo = electronesTotales / electronesAnodo;
                        int factorCatodo = electronesTotales / electronesCatodo;

                        int coefAnodoReactivo = factorAnodo * coeficientesReducidos[indiceAnodo];
                        String anodoReactivo = (coefAnodoReactivo == 1)
                                ? especiesReducidas[indiceAnodo]
                                : coefAnodoReactivo + especiesReducidas[indiceAnodo];

                        int coefAnodoProducto = factorAnodo * coeficientesOxidados[indiceAnodo];
                        String anodoProducto = (coefAnodoProducto == 1)
                                ? especiesOxidadas[indiceAnodo]
                                : coefAnodoProducto + especiesOxidadas[indiceAnodo];

                        int coefCatodoReactivo = factorCatodo * coeficientesOxidados[indiceCatodo];
                        String catodoReactivo = (coefCatodoReactivo == 1)
                                ? especiesOxidadas[indiceCatodo]
                                : coefCatodoReactivo + especiesOxidadas[indiceCatodo];

                        int coefCatodoProducto = factorCatodo * coeficientesReducidos[indiceCatodo];
                        String catodoProducto = (coefCatodoProducto == 1)
                                ? especiesReducidas[indiceCatodo]
                                : coefCatodoProducto + especiesReducidas[indiceCatodo];

                        System.out.println();
                        System.out.println("Ánodo espontáneo (se oxida / se corroe): " + nombresMetales[indiceAnodo]);
                        System.out.println("Cátodo espontáneo (se reduce / se protege): " + nombresMetales[indiceCatodo]);

                        if (potencialesEstandar[indiceAnodo] > potencialesEstandar[indiceCatodo]) {
                            System.out.println("Nota: Las concentraciones no estándar invirtieron la polaridad respecto a condiciones estándar.");
                        }

                        System.out.println();
                        System.out.println("Potenciales de la celda (E_1 - E_2):");
                        System.out.printf("Potencial estándar (E° celda): %+.4f V%n", femEstandarRedondeada);
                        if (tipoCondicion == 2) {
                            System.out.printf("Potencial real con Nernst (E celda): %+.4f V%n", femRealRedondeada);
                        }

                        if (femRealRedondeada > 0) {
                            System.out.println("Signo positivo (+): El proceso es espontáneo con Electrodo 1 como cátodo y Electrodo 2 como ánodo.");
                        } else {
                            System.out.println("Signo negativo (-): El proceso no es espontáneo en el orden ingresado (el Electrodo 1 actúa como ánodo real).");
                        }

                        System.out.println();
                        System.out.println("Electrones involucrados:");
                        System.out.println("Electrones liberados por unidad de ánodo: " + electronesAnodo + "e-");
                        System.out.println("Electrones ganados por unidad de cátodo: " + electronesCatodo + "e-");
                        System.out.println("Total de electrones transferidos en el balanceo: " + electronesTotales + "e-");

                        System.out.println();
                        System.out.println("Ecuaciones balanceadas (reacción espontánea):");
                        System.out.println("Oxidación (Ánodo): " + anodoReactivo + " -> " + anodoProducto + " + " + electronesTotales + "e-");
                        System.out.println("Reducción (Cátodo): " + catodoReactivo + " + " + electronesTotales + "e- -> " + catodoProducto);
                        System.out.println("Ecuación global: " + anodoReactivo + " + " + catodoReactivo + " -> " + anodoProducto + " + " + catodoProducto);
                    }
                    break;

                case 2:
                    System.out.println();
                    System.out.println("Tabla de potenciales estándar de oxidación (E°):");
                    for (int i = 0; i < nombresMetales.length; i++) {
                        String reactivo = (coeficientesReducidos[i] == 1)
                                ? especiesReducidas[i]
                                : coeficientesReducidos[i] + especiesReducidas[i];

                        String producto = (coeficientesOxidados[i] == 1)
                                ? especiesOxidadas[i]
                                : coeficientesOxidados[i] + especiesOxidadas[i];

                        System.out.printf("%d. %s | %s -> %s + %de- | E° = %+.3f V%n",
                                (i + 1), nombresMetales[i], reactivo, producto, electronesTabla[i], potencialesEstandar[i]);
                    }
                    break;

                case 3:
                    System.out.println();
                    System.out.println("Programa elaborado Por los Ingenieros :");
                    System.out.println("Ilyan Leonardo Hernández Irala\n" +
                            "Bernardo de León Hernández\n" +
                            "Draco Leonardo Porras Alcalá\n");
                    System.out.println("Saliendo del programa...");
                    continuar = false;
                    break;
            }

        } while (continuar);
    }
}
